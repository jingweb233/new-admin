<template>
    <div>
        <el-card>Footer</el-card>       
    </div>
</template>

<script>
export default {
    name:"FooterComponent",
    data(){
        return{

        }
    }
}
</script>

<style lang="scss" scoped>

</style>