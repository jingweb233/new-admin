<template>
    <div class="">
        travelmap
    </div>
</template>

<script>
export default {
    
}
</script>