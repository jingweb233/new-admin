<template>
    <div class="">
        dataview
    </div>
</template>

<script>
export default {
    
}
</script>