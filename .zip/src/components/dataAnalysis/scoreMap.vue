<template>
    <div class="">
        scoremap
    </div>
</template>

<script>
export default {
    
}
</script>