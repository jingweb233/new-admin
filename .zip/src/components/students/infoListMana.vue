<template>
    <div class="">
        infolists
    </div>
</template>

<script>
export default {
    
}
</script>